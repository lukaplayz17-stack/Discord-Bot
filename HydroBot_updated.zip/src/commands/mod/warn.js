import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';

const warns = new Map();

export default {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a user')
    .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const id = user.id;
    warns.set(id, (warns.get(id) || 0) + 1);
    const count = warns.get(id);

    // Escalations
    if (count === 3) {
      const member = await interaction.guild.members.fetch(id);
      await member.timeout(10 * 60 * 1000, '3 warnings => timeout');
      return interaction.reply(`⚠️ ${user} warned (${count}) and timed out for 10 min.`);
    }
    if (count === 5) {
      const member = await interaction.guild.members.fetch(id);
      await member.ban({ reason: '5 warnings => ban' });
      return interaction.reply(`🚫 ${user} has been banned.`);
    }

    return interaction.reply(`⚠️ ${user} warned (${count})`);
  }
}
