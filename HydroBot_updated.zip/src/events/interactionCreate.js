export default {
  name: 'interactionCreate',
  async execute(interaction, client) {
    // Slash commands
    if (interaction.isChatInputCommand()) {
      const cmd = client.commands.get(interaction.commandName);
      if (cmd) return cmd.execute(interaction, client);
    }

    // Verify button for captcha
    if (interaction.isButton() && interaction.customId === 'verify_me') {
      try {
        const role = interaction.guild.roles.cache.find(r => r.name === 'Disciples');
        if (!role) return interaction.reply({ content: 'Role not found.', ephemeral: true });

        await interaction.member.roles.add(role);
        return interaction.reply({ content: '✅ Verified! Role added.', ephemeral: true });
      } catch {
        return interaction.reply({ content: 'Error giving role.', ephemeral: true });
      }
    }
  }
}
