import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } from 'discord.js';

export default {
  name: 'guildMemberAdd',
  async execute(member) {
    const channel = member.guild.channels.cache.find(c => c.name === 'welcome');
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setTitle('Welcome!')
      .setDescription(`Hello <@${member.id}>! Please verify to access the server.`);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('verify_me')
        .setLabel('Verify')
        .setStyle(ButtonStyle.Success)
    );

    await channel.send({ embeds: [embed], components: [row] });
  }
}
