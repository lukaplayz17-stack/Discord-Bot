# HydroBot (Updated)
Features:
- Join Captcha (verify button)
- Auto-role: Disciples
- Welcome Messages
- Warn -> Mute -> Ban system
...
