import fs from 'fs';
import path from 'path';
import { Client, Collection, GatewayIntentBits, Partials } from 'discord.js';
import dotenv from 'dotenv';
dotenv.config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Message, Partials.Channel]
});

client.commands = new Collection();

// Load commands
const commandsPath = path.join(process.cwd(), 'src/commands');
for (const folder of fs.readdirSync(commandsPath)) {
  const folderPath = path.join(commandsPath, folder);
  for (const file of fs.readdirSync(folderPath)) {
    if (file.endsWith('.js')) {
      const cmd = await import(`./src/commands/${folder}/${file}`);
      client.commands.set(cmd.default.data.name, cmd.default);
    }
  }
}

// Load events
const eventsPath = path.join(process.cwd(), 'src/events');
for (const file of fs.readdirSync(eventsPath)) {
  if (file.endsWith('.js')) {
    const ev = await import(`./src/events/${file}`);
    if (ev.default.once) {
      client.once(ev.default.name, (...args) => ev.default.execute(...args, client));
    } else {
      client.on(ev.default.name, (...args) => ev.default.execute(...args, client));
    }
  }
}

client.login(process.env.TOKEN);
